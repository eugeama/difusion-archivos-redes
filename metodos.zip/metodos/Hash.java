package metodos2;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class Hash {

    //esto no lo explico pq es medio obvio que hace y se entiende como funciona el hash.
    //no tiene nada que digamos uy que raro que es esto
    public static byte[] hashearDatos(byte[] datos) throws NoSuchAlgorithmException {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        return digest.digest(datos);
    }
}
