package metodos2;

import javax.crypto.SecretKey;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.security.PrivateKey;
import java.security.PublicKey;

//profe la clase usa runnable porque está constantemente escuchando lo que le llega, pq
//no es que le mandan un archivo y se cierra, está siempre hata que el server se
//apaga
public class ReceptorArchivo implements Runnable {
    private final DataInputStream in;
    private final File carpetaEnviado;
    private final PrivateKey myPrivateKey;
    private final PublicKey serverPublicKey;
    private final SecretKey aesCompartida;


    public ReceptorArchivo(DataInputStream in, File carpetaEnviado, File carpetaAsim, PrivateKey myPrivateKey, PublicKey serverPublicKey, SecretKey aesCompartida) throws Exception {
        this.in = in;
        this.carpetaEnviado = carpetaEnviado;
        this.myPrivateKey = myPrivateKey;
        this.serverPublicKey = serverPublicKey;
        this.aesCompartida =  aesCompartida;

        if (!carpetaEnviado.exists()) carpetaEnviado.mkdirs();
        if (!carpetaAsim.exists()) carpetaAsim.mkdirs();
    }

    //acá se leen los mensajes y se mandan a descifrar en procesarArchivo, así de simple
    @Override
    public void run() {
        try {
            while (true) {
                archivo archivoMandado = leerArchivo();
                procesarArchivo(archivoMandado);
            }
        } catch (IOException e) {
            System.out.println("Conexión cerrada en ReceptorArchivo.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static class archivo {
        byte[] nombreEnc;
        byte[] datosEnc;
        byte[] firmaNombre;
        byte[] firmaDatos;
    }

    //acá se lee todo lo que mandamos desde clienteHandler
    private archivo leerArchivo() throws IOException {
        archivo leerMandado = new archivo();

        int nombreEncriptado = in.readInt();
        leerMandado.nombreEnc = new byte[nombreEncriptado];
        in.readFully(leerMandado.nombreEnc);

        long datosEncriptados = in.readLong();
        leerMandado.datosEnc = new byte[(int) datosEncriptados];
        in.readFully(leerMandado.datosEnc);

        int firmaNombre = in.readInt();
        leerMandado.firmaNombre = new byte[firmaNombre];
        in.readFully(leerMandado.firmaNombre);

        int firmaDatos = in.readInt();
        leerMandado.firmaDatos = new byte[firmaDatos];
        in.readFully(leerMandado.firmaDatos);

        return leerMandado;
    }

    //acá se desencripta todo y si está todo tranqui, o sea si el okNombre y okDatos dicen
    //que todo coincide entonces guarda los archivos 💪💪💪 (este emoji lo copie yo
    //de google profe te lo prometo)
    private void procesarArchivo(archivo msg) throws Exception {
        SecretKey claveAES = aesCompartida;

        byte[] nombreBytes = EncriptacionYDesencriptacion.desencriptarConAES(msg.nombreEnc, claveAES);
        byte[] dataBytes = EncriptacionYDesencriptacion.desencriptarConAES(msg.datosEnc, claveAES);
        String nombreArchivo = new String(nombreBytes, StandardCharsets.UTF_8);

        byte[] hNombre = EncriptacionYDesencriptacion.hashear(nombreBytes);
        byte[] hDatos = EncriptacionYDesencriptacion.hashear(dataBytes);

        boolean okNombre = EncriptacionYDesencriptacion.verificarFirma(hNombre, msg.firmaNombre, serverPublicKey);
        boolean okDatos = EncriptacionYDesencriptacion.verificarFirma(hDatos, msg.firmaDatos, serverPublicKey);

        if (okNombre && okDatos) {
            guardarArchivo(nombreArchivo, dataBytes, carpetaEnviado);
        }
    }

    //esto hace lo que dice (es declarativo como pediste), si está todo bien entonces
    //le van a llegar los datos desencriptados a esto y los va a guardar como archivo
    //usando el fileoutputstream que justamente sirve para escribir datos. en este caso nosotros
    //los escribimos en archivo que va a estar en la carpeta, que es el enviado que se le
    //pide al cliente cuando se prende cliente, y además tiene el nombre del archivo para
    //saber que nombre ponerle
    private void guardarArchivo(String nombreArchivo, byte[] datosArchivo, File carpeta) {
        File archivo = new File(carpeta, nombreArchivo);
        try (FileOutputStream fos = new FileOutputStream(archivo)) {
            fos.write(datosArchivo);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
