package metodos2;

import javax.crypto.SecretKey;
import java.io.*;
import java.net.Socket;
import java.security.KeyPair;
import java.security.PublicKey;
import java.util.Scanner;

public class Cliente {
    //hola profe este metodo es fácil. busca si existe la carpeta que le pasan (que siempre debería ser
    //enviado), y si no está la crea con mkdir, que sirve para crear directorios
    public static void crearCarpeta(File carpetaEnviado) {
        if (!carpetaEnviado.exists() || !carpetaEnviado.isDirectory()) {
            carpetaEnviado.mkdirs();
        }
    }

    //esto lo que hace es agarrar la clave pública del cliente y se la manda al servidor
    //.getEncoded() sirve para como pasar los datos que devuelve .getPublic(), que es la clave pública del
    //cliente, a un array de bytes
    //el flush es lo mismo que la otra vez que nos preguntaste, manda todo lo que haya quedado en el socket
    public static void enviarClavePublica(DataOutputStream out, KeyPair myPair) throws IOException {
        byte[] myPub = myPair.getPublic().getEncoded();
        out.writeInt(myPub.length);
        out.write(myPub);
        out.flush();
    }

    //clavePubServidorT esto guarda el tamaño de la clave pública del server, y clavePubS hace un array de
    //bytes de ese mismo tamaño.
    //lee la cant de bytes que le llegan del socket, solo la misma cantidad que el tamaño de clavePublicaS
    //así sabe que lo que recibe es la clave pública
    //.bytesToPublicKey es un método que tenemos que justamente lo que hace es pasar los bytes que recibe
    //a una clave pública
    public static PublicKey recibirClavePubServidor(DataInputStream in) throws Exception {
        int clavePubServidorT = in.readInt();
        byte[] clavePublicaS = new byte[clavePubServidorT];
        in.readFully(clavePublicaS);

        return EncriptacionYDesencriptacion.crearLlavePublica(clavePublicaS);
    }

    public static SecretKey mandarClaveSimetrica(DataInputStream in, KeyPair myPair) throws Exception {
        int tAES = in.readInt();
        byte[] aesCifradaServer = new byte[tAES];
        in.readFully(aesCifradaServer);

        return EncriptacionYDesencriptacion.desencriptarClaveRSA(aesCifradaServer, myPair.getPrivate());
    }



    // crea un array de bytes que tiene el tamaño de archivo, lo que va a mandar el cliente
    //el try sirve para que puedas leer archivos sin tener que escribir vos a mano que se cierre el archivo
    //despues de leerlo. además sigue aunque haya excepciones, es mejor que hacerlo a mano
    //se crea un fileInputStream que lo que hace es justamente, leer lo que se manda en este caso por archivos
    //lo va leyendo blablabla
    //después lo otro es emdio lo mismo que teníamos en la primera parte de este tp. manda todo por el socket,
    //incluyendo el nombre del archivo, el tamaño, el archivo tipo entero pero en bytes y después un flush
    //para mandar lo que había quedado
    public static void mandarArchivos(File archivo, DataOutputStream out) throws IOException {
        byte[] dataArchivo = new byte[(int) archivo.length()];
        try (FileInputStream fis = new FileInputStream(archivo)) {
            int leidos = 0;
            while (leidos < dataArchivo.length) {
                int n = fis.read(dataArchivo, leidos, dataArchivo.length - leidos);
                if (n < 0) break;
                leidos += n;
            }
        }

        out.writeUTF(archivo.getName());
        out.writeLong(dataArchivo.length);
        out.write(dataArchivo);
        out.flush();
    }

    //literal un bucle que pregunta por archivos para mandar, y si no lo encuentra salta error
    public static void bucleMandarArchivos(Scanner scanner, DataOutputStream out) throws IOException {
        while (true) {
            System.out.print("Ingrese la ruta del archivo para enviar (o 'salir'): ");
            String ruta = scanner.nextLine();
            if ("salir".equalsIgnoreCase(ruta)) break;

            File archivo = new File(ruta);
            if (!archivo.exists() || !archivo.isFile()) {
                System.out.println("Archivo no encontrado. Intente otra ruta.");
                continue;
            }
            mandarArchivos(archivo, out);
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        //acá pregunta por la carpeta enviado del primer método
        System.out.print("Ingrese la ruta de la carpeta 'enviado' (local): ");
        String rutaCarpeta = scanner.nextLine();
        File carpetaEnviado = new File(rutaCarpeta);
        crearCarpeta(carpetaEnviado);

        //se conecta al server con el socket, aacá también se usa el try que va a cerrar el socket cuando
        //se deje de usar
        try (Socket socket = new Socket(args[0], 5000)) {

            DataInputStream in = new DataInputStream(socket.getInputStream());
            DataOutputStream out = new DataOutputStream(socket.getOutputStream());

            KeyPair myPair = LlavePubPriv.crearParLlave();
            enviarClavePublica(out, myPair);
            PublicKey serverPublicKey = recibirClavePubServidor(in);
            SecretKey serverKeySimetrica= mandarClaveSimetrica(in, myPair);

            File carpetaSim = new File("recibidos_sim");
            File carpetaAsim = new File("recibidos_asim");
            if (!carpetaSim.exists()) carpetaSim.mkdirs();
            if (!carpetaAsim.exists()) carpetaAsim.mkdirs();

            ReceptorArchivo receptor = new ReceptorArchivo(in, carpetaEnviado, carpetaAsim, myPair.getPrivate(), serverPublicKey, serverKeySimetrica);
            new Thread(receptor).start();

            bucleMandarArchivos(scanner, out);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
