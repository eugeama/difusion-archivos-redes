package metodos2;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import java.security.*;
import java.security.spec.X509EncodedKeySpec;

public class EncriptacionYDesencriptacion {

    // Convierte bytes a clave pública o privada, depende de lo que quieras. acá es pública
    //keyFactory es un coso que encontramos que lo que hace es agarrar claves opacas, o sea que tienen como
    //una capa extra de seguridad, y generar claves públicas o privadas a partir de eso.
    //acá le pasamos los bytes que conseguimos cuando hacemos el handshake con el server desde el cliente,
    //y de ahí lo vuelve una clave opaca que después pasa a clave pública con el .generatePublic()
    public static PublicKey crearLlavePublica(byte[] bytesPublicos) throws Exception {
        KeyFactory convertidorLlaves = KeyFactory.getInstance("RSA");
        X509EncodedKeySpec opacas = new X509EncodedKeySpec(bytesPublicos);
        return convertidorLlaves.generatePublic(opacas);
    }

    // lit encripta una clave AES con la pública de la persona que lo recibe
    //se lo mandamos con .getEncoded() así el que lo recibe lo desencripta con su privada
    public static byte[] encriptarClaveRSA(SecretKey claveAES, PublicKey llavePublicaD) throws Exception {
        Cipher encriptar = Cipher.getInstance("RSA");
        encriptar.init(Cipher.ENCRYPT_MODE, llavePublicaD);
        return encriptar.doFinal(claveAES.getEncoded());
    }

    //todos losmétodos que siguen son medio lo mismo, todo encriptar  odesencriptar con
    //cipher
    public static SecretKey desencriptarClaveRSA(byte[] claveCifrada, PrivateKey privada) throws Exception {
        Cipher rsa = Cipher.getInstance("RSA");
        rsa.init(Cipher.DECRYPT_MODE, privada);
        byte[] keyBytes = rsa.doFinal(claveCifrada);
        return new SecretKeySpec(keyBytes, "AES");
    }

    public static byte[] encriptarConAES(byte[] datos, SecretKey clave) throws Exception {
        Cipher aes = Cipher.getInstance("AES");
        aes.init(Cipher.ENCRYPT_MODE, clave);
        return aes.doFinal(datos);
    }

    public static byte[] desencriptarConAES(byte[] datos, SecretKey clave) throws Exception {
        Cipher aes = Cipher.getInstance("AES");
        aes.init(Cipher.DECRYPT_MODE, clave);
        return aes.doFinal(datos);
    }

    //firma con la privada los datos
    public static byte[] firmar(byte[] datos, PrivateKey privada) throws Exception {
        Signature firma = Signature.getInstance("SHA256withRSA");
        firma.initSign(privada);
        firma.update(datos);
        return firma.sign();
    }

    //acá lo que hace es que verifica la firma. se desencripta con la pública y ve si los
    //datos que hay en firmaByte coinciden con los datos og
    public static boolean verificarFirma(byte[] datos, byte[] firmaBytes, PublicKey publica) throws Exception {
        Signature firma = Signature.getInstance("SHA256withRSA");
        firma.initVerify(publica);
        firma.update(datos);
        return firma.verify(firmaBytes);
    }

    //lit hashear profe, no sé que mas decir
    public static byte[] hashear(byte[] datos) throws Exception {
        return Hash.hashearDatos(datos);
    }
}
