package metodos2;

import javax.crypto.SecretKey;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.security.*;
import java.util.HashSet;
import java.util.Set;

//acá se usa runnable pq así por cada cliente va a haber un hilo
public class ClienteHandler implements Runnable {
    private final Socket socket;
    private final DataInputStream in;
    private final DataOutputStream out;
    private final Set<ClienteHandler> clientes;
    private final KeyPair servidorKeyPair;
    private PublicKey clientePublicKey;

    // NUEVO: guardamos la clave AES compartida con ESTE cliente
    private SecretKey aesCompartidaConCliente;

    public ClienteHandler(Socket socket, Set<ClienteHandler> clientes, KeyPair servidorKeyPair) throws NoSuchAlgorithmException, IOException {
        this.socket = socket;
        this.in = new DataInputStream(socket.getInputStream());
        this.out = new DataOutputStream(socket.getOutputStream());
        this.clientes = clientes;
        this.servidorKeyPair = servidorKeyPair;

        try {
            handshake();
            enviarClaveSimetricaAlCliente();
        } catch (Exception e) {
            throw new IOException("Error en handshake con cliente: " + e.getMessage(), e);
        }
    }

    //este es medio el mismo método que había en cliente, hace hansdshake para conseguir
    //la clave púublica del cliente y agarra y pasa la privada del server
    private void handshake() throws Exception {
        int len = in.readInt();
        byte[] pubBytes = new byte[len];
        in.readFully(pubBytes);
        this.clientePublicKey = EncriptacionYDesencriptacion.crearLlavePublica(pubBytes);

        byte[] servidorPub = servidorKeyPair.getPublic().getEncoded();
        out.writeInt(servidorPub.length);
        out.write(servidorPub);
        out.flush();
    }

    // NUEVO: ahora este método guarda la clave AES en el campo aesCompartidaConCliente
    private void enviarClaveSimetricaAlCliente() throws Exception {
        // generar AES
        SecretKey aes = LlaveAleatoria.generarLlave();

        // Guardarla en este handler para usarla luego al cifrar para este cliente
        this.aesCompartidaConCliente = aes;

        // encriptar con la pública del cliente
        byte[] aesEnc = EncriptacionYDesencriptacion.encriptarClaveRSA(aes, clientePublicKey);

        // mandar al cliente
        out.writeInt(aesEnc.length);
        out.write(aesEnc);
        out.flush();
    }

    // getter público para que otros handlers puedan obtener la AES de este cliente
    public SecretKey getAesCompartidaConCliente() {
        return aesCompartidaConCliente;
    }

    public DataOutputStream getOut() {
        return out;
    }

    public PublicKey getClientePublicKey() {
        return clientePublicKey;
    }

    @Override
    public void run() {
        try {
            recibirDatos();
        } catch (IOException e) {
            System.out.println("Cliente desconectado");
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                socket.close();
            } catch (IOException ignored) {}
            clientes.remove(this);
        }
    }

    private void recibirDatos() throws Exception {
        while (true) {
            String nombreArchivo = in.readUTF();
            long tamanio = in.readLong();
            if (tamanio > Integer.MAX_VALUE) {
                System.out.println("Archivo demasiado grande, se ignora: " + nombreArchivo);
                in.skip(tamanio);
                continue;
            }
            byte[] data = new byte[(int) tamanio];
            in.readFully(data);

            recorrerClientesAMandar(nombreArchivo, data);
        }
    }

    private void recorrerClientesAMandar(String nombreArchivo, byte[] data) {
        for (ClienteHandler cliente : new HashSet<>(clientes)) {
            if (cliente == this) continue;
            try {
                mandarArchivos(cliente, nombreArchivo, data);
            } catch (Exception ex) {
                clientes.remove(cliente);
            }
        }
    }


    //acá hace toda la encriptación simétrica y asimétrica y se lo va a mandar al server
    //para que se lo mande a todos, o sea que va a llegar a receptorArchivo
    //safebutes lo usamos para que no se escriba null en el array de bytes, así es
    //justamente, más seguro el mandado y puede haber menos errores
    private void mandarArchivos(ClienteHandler destino, String nombreArchivo, byte[] data) throws Exception {
        // CAMBIO: ya no generamos una nueva AES aquí. Usamos la AES previamente establecida
        SecretKey aesDestino = destino.getAesCompartidaConCliente();

        if (aesDestino == null) {
            // Si por alguna razon la clave AES de ese cliente no fue establecida, lo salteamos
            // (podríamos intentar re-handshake en el futuro)
            System.out.println("No hay AES compartida con el cliente destino, se omite el envío");
            return;
        }

        byte[] nombreEnc = EncriptacionYDesencriptacion.encriptarConAES(nombreArchivo.getBytes(), aesDestino);
        byte[] datosEnc = EncriptacionYDesencriptacion.encriptarConAES(data, aesDestino);

        byte[] nombreHash = EncriptacionYDesencriptacion.hashear(nombreArchivo.getBytes());
        byte[] datosHash = EncriptacionYDesencriptacion.hashear(data);
        byte[] firmaNombre = EncriptacionYDesencriptacion.firmar(nombreHash, servidorKeyPair.getPrivate());
        byte[] firmaDatos = EncriptacionYDesencriptacion.firmar(datosHash, servidorKeyPair.getPrivate());

        DataOutputStream outDestino = destino.getOut();
        synchronized (outDestino) {
            outDestino.writeInt(nombreEnc.length);
            outDestino.write(safeBytes(nombreEnc));
            outDestino.writeLong(datosEnc.length);
            outDestino.write(datosEnc);
            outDestino.writeInt(firmaNombre.length);
            outDestino.write(firmaNombre);
            outDestino.writeInt(firmaDatos.length);
            outDestino.write(firmaDatos);
            outDestino.flush();
        }
    }

    private byte[] safeBytes(byte[] b) {
        return b == null ? new byte[0] : b;
    }
}