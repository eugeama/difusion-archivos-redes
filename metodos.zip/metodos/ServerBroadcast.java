package metodos2;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.security.KeyPair;
import java.security.NoSuchAlgorithmException;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public class ServerBroadcast {
    private final int puerto;
    private final KeyPair parLlave;
    private final Set<ClienteHandler> clientes = ConcurrentHashMap.newKeySet();

    public ServerBroadcast(int puerto) throws NoSuchAlgorithmException {
        this.puerto = puerto;
        this.parLlave = LlavePubPriv.crearParLlave();
    }

    //se prende el server en el puerto que le mandemos con un socket, y de ah{i usamos
    // el try por la misma razón que las últimas 2/3 veces, porque después te cierra
    // el puerto automáticamente.
    //después cuando un cliente se conecta se hace un socket para ese cliente y se manda
    //a agregar cliente apra que esté en la lista de los que se van a mandar los archivos
    public void iniciarPuerto() {
        System.out.println("Servidor iniciado en el puerto " + puerto);
        try (ServerSocket serverSocket = new ServerSocket(puerto)) {
            while (true) {
                Socket socketCliente = serverSocket.accept();
                agregarClienteYAvisar(socketCliente);
            }
        } catch (IOException | NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
    }

    //le hace un nuevo clientehandler al cliente así los podemos controlar a los clientes
    //de a uno
    //mete el nuevo cliente en la loista de clientes que se le van a mandar cosas y le
    //hacemos un thread para mandarle cosas
    //no se si está bien tener un sout aca pq pediste que no tuvieramos avisos innecesarios,
    //pero así nosotros sabemos bien si se conecta alguien o no
    private void agregarClienteYAvisar(Socket socketCliente) throws NoSuchAlgorithmException, IOException {
        ClienteHandler NuevoClienteC = new ClienteHandler(socketCliente, clientes, parLlave);
        clientes.add(NuevoClienteC);
        new Thread(NuevoClienteC).start();
        System.out.println("Nuevo cliente conectado: " + socketCliente.getRemoteSocketAddress());
    }

    public static void main(String[] args) throws NoSuchAlgorithmException {
        ServerBroadcast server = new ServerBroadcast(5000);
        server.iniciarPuerto();
    }
}
